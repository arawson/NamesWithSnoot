
# Names with Snoot

A set of personalized renamings based on the long lineages of renaming mods.
*WARNING* This has swearing and dirty jokes. Viewer discretion is advised.

According to Ty's Improved Names and Quak's improved names, this will not work
with rorcheats. So take that for what you will, I have no idea what that is.

## Examples

Uncommon:
Predatory Instincts -> Wobbly Snoot

## Updates

0.0.1: First version, what more could you want?

0.0.2: New ideas from playing Survivors of the Void

0.0.3: Even more bad name ideas (and a few descriptions too) for Seekers of the Storm.
